import React from 'react'
import LoginScreen from '../../Component/Login/Login'
import Background from '../../Component/UI/Background'
import '../../Style/UserStyle.css'

function UserLogin() {
    return (
        <div>
            <Background>
                <LoginScreen></LoginScreen>
            </Background>
        </div>
    )
}

export default UserLogin

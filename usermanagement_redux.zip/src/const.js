export const data={
    isUserLogged:true,
    isAdminLogged:true
}